// =====================================================================
// PML RELAY - INVENTORY & TRACEABILITY SYSTEM
// Backend (Code.gs) — JSON API version
//
// This file no longer serves the HTML page. It ONLY exposes a JSON API
// via doGet (for reads) and doPost (for writes). The actual web page
// (index.html + style.css + app.js) is hosted separately (e.g. GitHub
// Pages) and talks to this API using fetch().
//
// After pasting this in, deploy: Deploy > New deployment > Web app
//   - Execute as: Me
//   - Who has access: Anyone
// Copy the resulting /exec URL — you'll paste it into the hosted page.
// =====================================================================
const SPREADSHEET_ID = "1AZ04Ch0OEBWaJwkZArXR32uuTcqf-2_oxSSFarW-Yhw";

// ---------------------------------------------------------------------
// ENTRY POINTS
// ---------------------------------------------------------------------
function doGet(e) {
  try {
    const action = e.parameter.action;
    let data;
    switch (action) {
      case 'getGlobalDropdowns': data = getGlobalDropdowns(); break;
      case 'getGRNProcesses':    data = getGRNProcesses(); break;
      case 'getBOMForPart':      data = getBOMForPart(e.parameter.partId); break;
      case 'getJobOrderTracker': data = getJobOrderTracker(); break;
      case 'getAssemblyTracker': data = getAssemblyTracker(); break;
      case 'traceSerialNumber':  data = traceSerialNumber(e.parameter.serialNumber); break;
      default: throw new Error('Unknown GET action: ' + action);
    }
    return jsonResponse({ success: true, data: data });
  } catch (err) {
    return jsonResponse({ success: false, message: err.message });
  }
}

function doPost(e) {
  try {
    // Body is sent as text/plain from the client (on purpose) to avoid
    // a CORS preflight request, which Apps Script web apps can't answer.
    const body = JSON.parse(e.postData.contents);
    const action = body.action;
    const payload = body.payload || {};
    let result;
    switch (action) {
      case 'setupDatabase':           result = setupDatabase(); break;
      case 'addGlobalDropdownItem':   result = addGlobalDropdownItem(payload); break;
      case 'addGRNProcess':           result = addGRNProcess(payload.name); break;
      case 'createJobOrder':          result = createJobOrder(payload); break;
      case 'createGRN':               result = createGRN(payload); break;
      case 'saveAssemblyComponents':  result = saveAssemblyComponents(payload); break;
      case 'registerSerial':          result = registerSerial(payload); break;
      case 'processEOLTest':          result = processEOLTest(payload); break;
      case 'processPDITest':          result = processPDITest(payload); break;
      default: throw new Error('Unknown POST action: ' + action);
    }
    return jsonResponse(result);
  } catch (err) {
    return jsonResponse({ success: false, message: err.message });
  }
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
      .setMimeType(ContentService.MimeType.JSON);
}

// ---------------------------------------------------------------------
// DATABASE SETUP
// ---------------------------------------------------------------------
function setupDatabase() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);

  const sheetDefs = {
    'Item_Master':               ['Part_ID', 'Part_Name', 'Part_Type', 'Min_Threshold'],
    'BOM_Recipes':                ['Final_Product_ID', 'Child_Part_ID', 'Qty_Required_Per_Unit'],
    'Job_Orders':                 ['JO_Number', 'Part_ID', 'Part_Type', 'Qty_Ordered', 'Dev_Status', 'Date_Created', 'Created_By'],
    'GRN_Log':                    ['GRN_Number', 'JO_Number', 'Part_ID', 'Qty_Received', 'GRN_Date', 'Date_Logged', 'Received_By', 'Release_To_Process'],
    'IQC_Log':                    ['IQC_ID', 'JO_Number', 'Part_ID', 'Qty_Inspected', 'Result', 'Deviation_Raised', 'Deviation_Approver', 'Deviation_Remarks', 'Inspector', 'Date'],
    'Assembly_Consumption_Log':   ['Final_Part_ID', 'Component_Part_ID', 'Consumed_JO_Number', 'Qty_Consumed', 'Date_Logged'],
    'Serialized_Relays':          ['Serial_Number', 'Part_ID', 'Marking_Date', 'EOL_Status', 'PDI_Status'],
    'Quality_Logs':               ['Timestamp', 'Serial_Number', 'Stage', 'Final_Status', 'Tester'],
    'GRN_Processes':              ['Process_Name'],
    'Global_Dropdowns':           ['Created_By', 'Part_ID', 'Final_Part_ID', 'Tester', 'Received_By', 'Inspector']
  };

  Object.keys(sheetDefs).forEach(name => {
    let sheet = ss.getSheetByName(name);
    if (!sheet) {
      sheet = ss.insertSheet(name);
      sheet.appendRow(sheetDefs[name]);
      sheet.getRange(1, 1, 1, sheetDefs[name].length).setFontWeight("bold").setBackground("#1a237e").setFontColor("#ffffff");
      sheet.setFrozenRows(1);
    }
  });

  return { success: true, message: "Database structure verified/created." };
}

// ---------------------------------------------------------------------
// GLOBAL DROPDOWNS
// ---------------------------------------------------------------------
function getGlobalDropdowns() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName('Global_Dropdowns');
  const baseDict = { Created_By: [], Part_ID: [], Final_Part_ID: [], Tester: [], Received_By: [], Inspector: [] };

  if (!sheet) return baseDict;

  const data = sheet.getDataRange().getValues();
  if (data.length === 0) return baseDict;

  const headers = data[0];
  let lists = { ...baseDict };

  for (let c = 0; c < headers.length; c++) {
    let colName = headers[c];
    if (lists[colName] !== undefined) {
      for (let r = 1; r < data.length; r++) {
        if (data[r][c] !== "") lists[colName].push(String(data[r][c]));
      }
    }
  }
  return lists;
}

function addGlobalDropdownItem(payload) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sheet = ss.getSheetByName('Global_Dropdowns');
  const defaultHeaders = ['Created_By', 'Part_ID', 'Final_Part_ID', 'Tester', 'Received_By', 'Inspector'];

  if (!sheet) {
    sheet = ss.insertSheet('Global_Dropdowns');
    sheet.appendRow(defaultHeaders);
  }

  let data = sheet.getDataRange().getValues();
  let headers = data.length > 0 ? data[0] : defaultHeaders;

  if (data.length === 0) sheet.appendRow(headers);

  if (headers.indexOf(payload.listName) === -1) {
    headers.push(payload.listName);
    sheet.getRange(1, headers.length).setValue(payload.listName);
  }

  const colIndex = headers.indexOf(payload.listName);

  for (let r = 1; r < data.length; r++) {
    if (String(data[r][colIndex]).toLowerCase() === payload.value.toLowerCase()) {
      return { success: true, message: "Already exists" };
    }
  }

  let targetRow = -1;
  for (let r = 1; r < data.length; r++) {
    if (data[r][colIndex] === "") { targetRow = r + 1; break; }
  }

  if (targetRow !== -1) {
    sheet.getRange(targetRow, colIndex + 1).setValue(payload.value);
  } else {
    let newRow = new Array(headers.length).fill("");
    newRow[colIndex] = payload.value;
    sheet.appendRow(newRow);
  }

  return { success: true, message: `Added to dropdowns.` };
}

// ---------------------------------------------------------------------
// UTILITIES
// ---------------------------------------------------------------------
function validateJONumber(jo) {
  const pattern = /^[SE]\d{2}\d{2}\d{4}$/;
  return pattern.test(jo);
}
function nextId(sheet, prefix) {
  return prefix + "-" + (sheet.getLastRow()) + "-" + Math.floor(Math.random() * 900 + 100);
}

// ---------------------------------------------------------------------
// 1. JOB ORDER
// ---------------------------------------------------------------------
function createJobOrder(payload) {
  if (!validateJONumber(payload.joNumber)) throw new Error("Invalid Job Order format.");
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName('Job_Orders');
  const existing = sheet.getDataRange().getValues();
  for (let i = 1; i < existing.length; i++) {
    if (existing[i][0] === payload.joNumber) throw new Error("This Job Order number already exists.");
  }
  const devStatus = payload.joNumber.charAt(0) === 'S' ? 'Development' : 'Production';
  sheet.appendRow([payload.joNumber, payload.partId, payload.partType, payload.qty, devStatus, new Date(), payload.person]);
  return { success: true, message: `Job Order ${payload.joNumber} created.` };
}

// ---------------------------------------------------------------------
// 2. GRN + IQC
// ---------------------------------------------------------------------
function getGRNProcesses() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName('GRN_Processes');
  if (!sheet) return [];
  const data = sheet.getDataRange().getValues().slice(1);
  return data.map(r => r[0]).filter(Boolean);
}

function addGRNProcess(name) {
  name = (name || "").trim();
  if (!name) throw new Error("Empty name.");
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  let sheet = ss.getSheetByName('GRN_Processes');
  if (!sheet) { sheet = ss.insertSheet('GRN_Processes'); sheet.appendRow(['Process_Name']); }
  const existing = sheet.getDataRange().getValues();
  for (let i = 1; i < existing.length; i++) {
    if (String(existing[i][0]).toLowerCase() === name.toLowerCase()) throw new Error("Process exists.");
  }
  sheet.appendRow([name]);
  return { success: true, message: `Process added.` };
}

function createGRN(payload) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const now = new Date();
  const grnSheet = ss.getSheetByName('GRN_Log');
  const processVal = payload.releaseProcess ? payload.releaseProcess : "-";
  grnSheet.appendRow([payload.grnNumber, payload.joNumber, payload.partId, payload.qty, payload.grnDate, now, payload.person, processVal]);

  const iqcSheet = ss.getSheetByName('IQC_Log');
  const iqcId = nextId(iqcSheet, "IQC");
  let devRaised = payload.result === 'ACCEPTED ON DEVIATION' ? 'Yes' : 'No';
  let iqcStatus = payload.result === 'ACCEPTED ON DEVIATION' ? 'Not OK' : payload.result;

  iqcSheet.appendRow([iqcId, payload.joNumber, payload.partId, payload.qty, iqcStatus, devRaised, '-', '-', payload.inspector, now]);
  return { success: true, message: `GRN and IQC logged successfully.` };
}

// ---------------------------------------------------------------------
// 3. ASSEMBLY
// ---------------------------------------------------------------------
function getBOMForPart(partId) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const bomData = ss.getSheetByName('BOM_Recipes').getDataRange().getValues();
  let components = [];
  for (let i = 1; i < bomData.length; i++) {
    if (bomData[i][0] === partId) components.push({ childPart: String(bomData[i][1]), qty: Number(bomData[i][2]) });
  }
  return components;
}

function saveAssemblyComponents(payload) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const grnSheet = ss.getSheetByName('GRN_Log');
  const asmSheet = ss.getSheetByName('Assembly_Consumption_Log');

  const grnData = grnSheet.getDataRange().getValues();
  const asmData = asmSheet.getDataRange().getValues();

  let requiredQtys = {};
  for (let c of payload.components) {
    const jo = c.joNumber;
    requiredQtys[jo] = (requiredQtys[jo] || 0) + Number(c.qty);
  }

  for (const [compJO, reqQty] of Object.entries(requiredQtys)) {
    let totalReceived = 0;
    for (let i = 1; i < grnData.length; i++) {
      if (grnData[i][1] === compJO) { totalReceived += Number(grnData[i][3]); }
    }
    if (totalReceived === 0) {
      throw new Error(`Validation Failed: Job Order ${compJO} has not been received via GRN yet.`);
    }
    let totalConsumed = 0;
    for (let i = 1; i < asmData.length; i++) {
      if (asmData[i][2] === compJO) { totalConsumed += Number(asmData[i][3]); }
    }
    const available = totalReceived - totalConsumed;
    if (reqQty > available) {
      throw new Error(`Inventory Shortage! JO: ${compJO} only has ${available} units available, but you are trying to consume ${reqQty}.`);
    }
  }

  const now = new Date();
  const rows = payload.components.map(c => [payload.finalPartId, c.partId, c.joNumber, c.qty, now]);
  asmSheet.getRange(asmSheet.getLastRow() + 1, 1, rows.length, 5).setValues(rows);

  return { success: true, message: `Assembly logged successfully.` };
}

// ---------------------------------------------------------------------
// 4. LASER MARKING
// ---------------------------------------------------------------------
function registerSerial(payload) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName('Serialized_Relays');
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] === payload.serialNumber) throw new Error("Serial exists.");
  }
  sheet.appendRow([payload.serialNumber, payload.partId, payload.markingDate, 'Pending', 'Pending']);
  return { success: true, message: `Serial registered.` };
}

// ---------------------------------------------------------------------
// 5. EOL & PDI TESTING
// ---------------------------------------------------------------------
function processEOLTest(payload) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const wipSheet = ss.getSheetByName('Serialized_Relays');
  const logSheet = ss.getSheetByName('Quality_Logs');
  const wipData = wipSheet.getDataRange().getValues();
  let rowIndex = -1;
  for (let i = 1; i < wipData.length; i++) {
    if (wipData[i][0] === payload.serialNumber) { rowIndex = i + 1; break; }
  }
  if (rowIndex === -1) throw new Error("Serial not found.");
  wipSheet.getRange(rowIndex, 4).setValue(payload.result);
  logSheet.appendRow([new Date(), payload.serialNumber, 'EOL', payload.result, payload.tester]);
  return { success: true, message: `EOL saved!` };
}

function processPDITest(payload) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const wipSheet = ss.getSheetByName('Serialized_Relays');
  const logSheet = ss.getSheetByName('Quality_Logs');
  const wipData = wipSheet.getDataRange().getValues();
  let rowIndex = -1;
  for (let i = 1; i < wipData.length; i++) {
    if (wipData[i][0] === payload.serialNumber) { rowIndex = i + 1; break; }
  }
  if (rowIndex === -1) throw new Error("Serial not found.");
  if (wipData[rowIndex - 1][3] !== 'Pass') throw new Error("Has not passed EOL.");
  wipSheet.getRange(rowIndex, 5).setValue(payload.result);
  logSheet.appendRow([new Date(), payload.serialNumber, 'PDI', payload.result, payload.tester]);
  return { success: true, message: `PDI saved!` };
}

// ---------------------------------------------------------------------
// TRACKERS & TRACE
// ---------------------------------------------------------------------
function getJobOrderTracker() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const jos = ss.getSheetByName('Job_Orders').getDataRange().getValues().slice(1);
  const grn = ss.getSheetByName('GRN_Log').getDataRange().getValues().slice(1);
  const iqc = ss.getSheetByName('IQC_Log').getDataRange().getValues().slice(1);
  const consumption = ss.getSheetByName('Assembly_Consumption_Log').getDataRange().getValues().slice(1);
  const result = jos.map(jo => {
    const joNumber = jo[0];
    let stage = "Job Order Raised";
    if (grn.some(r => r[1] === joNumber)) stage = "GRN Received";
    if (iqc.some(r => r[1] === joNumber)) stage = "IQC Done";
    const consumedRow = consumption.find(r => r[2] === joNumber);
    if (consumedRow) stage = `Consumed in ${consumedRow[0]}`;
    return { joNumber: joNumber, partId: jo[1], partType: jo[2], qty: jo[3], devStatus: jo[4], currentStage: stage };
  });
  return result.reverse();
}

function getAssemblyTracker() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const consumption = ss.getSheetByName('Assembly_Consumption_Log').getDataRange().getValues().slice(1);
  const serials = ss.getSheetByName('Serialized_Relays').getDataRange().getValues().slice(1);
  const finalParts = [...new Set(consumption.map(r => r[0]))];
  const result = finalParts.map(partId => {
    const componentCount = consumption.filter(r => r[0] === partId).length;
    const relatedSerials = serials.filter(r => r[1] === partId);
    let stage = "Components Recorded";
    if (relatedSerials.length > 0) stage = "Laser Marked";
    if (relatedSerials.length > 0 && relatedSerials.every(r => r[3] === 'Pass')) stage = "EOL Passed";
    if (relatedSerials.length > 0 && relatedSerials.every(r => r[4] === 'Pass')) stage = "PDI Passed";
    return { finalPartId: partId, componentCount: componentCount, serialCount: relatedSerials.length, currentStage: stage };
  });
  return result.reverse();
}

function traceSerialNumber(serialNumber) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const serials = ss.getSheetByName('Serialized_Relays').getDataRange().getValues();
  const quality = ss.getSheetByName('Quality_Logs').getDataRange().getValues();
  let trace = { serialNumber, found: false, core: {}, quality: [], components: [] };
  let partId = null;
  for (let i = 1; i < serials.length; i++) {
    if (serials[i][0] === serialNumber) {
      trace.found = true;
      trace.core = { partId: serials[i][1], markingDate: serials[i][2] ? Utilities.formatDate(new Date(serials[i][2]), Session.getScriptTimeZone(), "dd/MM/yyyy") : "N/A", eolStatus: serials[i][3], pdiStatus: serials[i][4] };
      partId = serials[i][1]; break;
    }
  }
  if (!trace.found) return trace;
  for (let i = 1; i < quality.length; i++) {
    if (quality[i][1] === serialNumber) {
      trace.quality.push({ timestamp: Utilities.formatDate(new Date(quality[i][0]), Session.getScriptTimeZone(), "dd/MM/yyyy HH:mm"), stage: quality[i][2], status: quality[i][3], tester: quality[i][4] });
    }
  }
  if (partId) {
    const consumption = ss.getSheetByName('Assembly_Consumption_Log').getDataRange().getValues().slice(1).filter(r => r[0] === partId);
    const jos = ss.getSheetByName('Job_Orders').getDataRange().getValues().slice(1);
    const grn = ss.getSheetByName('GRN_Log').getDataRange().getValues().slice(1);
    const iqc = ss.getSheetByName('IQC_Log').getDataRange().getValues().slice(1);
    trace.components = consumption.map(row => {
      const compPartId = row[1], compJO = row[2], qtyConsumed = row[3];
      return { componentPartId: compPartId, consumedJO: compJO, qtyConsumed: qtyConsumed, jobOrder: jos.find(r => r[0] === compJO) || null, grn: grn.filter(r => r[1] === compJO), iqc: iqc.filter(r => r[1] === compJO) };
    });
  }
  return trace;
}
